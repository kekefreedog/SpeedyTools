package speedytools.common.items;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

import java.util.List;

public class ItemSpeedyTester extends ItemSpeedyTool {
  public static final String NAME = "tester";
  public ItemSpeedyTester() {
    super(PlacementCountModes.FINITE_ONLY);
    func_77625_d(64);
    func_77655_b(NAME);
    func_77664_n();                              // setting this flag causes the sceptre to render vertically in 3rd person view, like a pickaxe
  }

  /**
   * allows items to add custom lines of information to the mouseover description
   */
  @Override
  public void func_77624_a(ItemStack itemStack, EntityPlayer entityPlayer, List textList, boolean useAdvancedItemTooltips)
  {
    textList.add("Right click: conduct test");
    textList.add("Control + mouse wheel: change test #");
    textList.add("                     : (64 = test all)");
  }
}