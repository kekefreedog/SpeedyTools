package speedytools.common.items;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import speedytools.SpeedyToolsMod;

import java.util.List;

public class ItemSpeedyOrb extends ItemSpeedyTool {
  public static final String NAME = "simpleorb";
  public ItemSpeedyOrb() {
    super(PlacementCountModes.BOTH);
    func_77625_d(64);
    func_77655_b(NAME);
    func_77664_n();                              // setting this flag causes the trowel to render vertically in 3rd person view, like a pickaxe
  }

  @Override
  public boolean showDurabilityBar(ItemStack stack) {
    return false;
  }

  @Override
  public String getVariantModelResLoc(String itemName, int metadata)
  {
    switch (metadata) {
      case INFINITE_MODE_DAMAGE:{
        return SpeedyToolsMod.prependModID(itemName + "_infinite");
      }
      default: {
        return SpeedyToolsMod.prependModID(itemName);
      }
    }
  }

  /**
   * allows items to add custom lines of information to the mouseover description
   */
  @Override
  public void func_77624_a(ItemStack itemStack, EntityPlayer entityPlayer, List textList, boolean useAdvancedItemTooltips)
  {
    textList.add("Right click: place blocks");
    textList.add("Left click: undo last place");
    textList.add("Control: hold down to allow diagonal");
    textList.add("Control + mouse wheel: change count");
  }
}