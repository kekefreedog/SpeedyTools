package speedytools.common.utilities;

import net.minecraft.util.EnumFacing;

/**
 * User: The Grey Ghost
 * Date: 8/02/14
 */
public class UsefulConstants
{
  static public final int FACE_NONE = -1;
  static public final int FACE_YNEG = 0;
  static public final int FACE_YPOS = 1;
  static public final int FACE_XNEG = 4;
  static public final int FACE_XPOS = 5;
  static public final int FACE_ZNEG = 2;
  static public final int FACE_ZPOS = 3;
  static public final int FACE_ALL = 7;

  {
    if (FACE_YNEG != EnumFacing.UP.func_176745_a() ||
        FACE_YPOS != EnumFacing.DOWN.func_176745_a() ||
        FACE_XPOS != EnumFacing.EAST.func_176745_a() ||
        FACE_XNEG != EnumFacing.WEST.func_176745_a() ||
        FACE_ZNEG != EnumFacing.NORTH.func_176745_a() ||
        FACE_ZPOS != EnumFacing.SOUTH.func_176745_a() ) {
      throw new AssertionError("UsefulConstants doesn't match EnumFacing");
    }
  }

}

