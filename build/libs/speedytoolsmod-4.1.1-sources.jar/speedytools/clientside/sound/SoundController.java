package speedytools.clientside.sound;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSound;
import net.minecraft.util.Vec3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
* User: The Grey Ghost
* Date: 17/04/2014
*/
public class SoundController
{
  public void playSound(PositionedSound sound)
  {
    Minecraft.func_71410_x().func_147118_V().func_147682_a(sound);
  }

  public void playSound(PositionedSound sound, SoundEffectTickLink soundEffectTickLink)
  {
    Minecraft.func_71410_x().func_147118_V().func_147682_a(sound);
    soundEffectsToTick.put(sound, soundEffectTickLink);
  }

  public void stopSound(PositionedSound sound)
  {
    Minecraft.func_71410_x().func_147118_V().func_147683_b(sound);
    soundEffectsToTick.remove(sound);
  }

  /** tick all the sounds that need it
   */
  public void onTick()
  {
    Iterator<Map.Entry<PositionedSound, SoundEffectTickLink>> tickEntry = soundEffectsToTick.entrySet().iterator();
    while (tickEntry.hasNext()) {
      Map.Entry<PositionedSound, SoundEffectTickLink> entry = tickEntry.next();
      PositionedSound sound = entry.getKey();
      SoundEffectTickLink link = entry.getValue();
      boolean keepTicking = link.onTick( Minecraft.func_71410_x().func_147118_V().func_147692_c(sound));
      if (!keepTicking) {
        tickEntry.remove();
      }
    }
  }

  /**
   * The tick link is used by the controller to tick a sound
   */
  public interface SoundEffectTickLink {
    /**
     * called by the controller every tick
     * @param stillPlaying true if the sound is still playing
     * @return true if the sound wants to keep ticking, false to stop
     */
    public boolean onTick(boolean stillPlaying);
  }

  private HashMap<PositionedSound, SoundEffectTickLink> soundEffectsToTick = new HashMap<PositionedSound, SoundEffectTickLink>();

//  public abstract class SoundControlLink
//  {
//    public abstract void startSound();
//    public abstract void stopSound();
//  }
//
//  private class SoundControlLinkDoNothing extends SoundControlLink
//  {
//    public  void startSound() {};
//    public  void stopSound() {};
//  }
}
