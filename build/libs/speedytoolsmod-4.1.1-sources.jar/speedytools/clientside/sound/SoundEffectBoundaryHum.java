package speedytools.clientside.sound;

import net.minecraft.client.audio.ITickableSound;
import net.minecraft.client.audio.PositionedSound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import speedytools.common.utilities.UsefulFunctions;

import net.minecraft.client.audio.ISound.AttenuationType;
/**
 * Created by TheGreyGhost on 8/10/14.
 */
public class SoundEffectBoundaryHum
{
  public SoundEffectBoundaryHum(SoundEffectNames i_soundEffectName, SoundController i_soundController, BoundaryHumUpdateLink i_boundaryHumUpdateLink)
  {
    soundEffectName = i_soundEffectName;
    soundController = i_soundController;
    resourceLocation = new ResourceLocation(soundEffectName.getJsonName());
    boundaryHumUpdateLink = i_boundaryHumUpdateLink;
  }

  public void startPlayingLoop()
  {
    if (boundaryFieldSound != null) {
      stopPlaying();
    }
    final float INITIAL_VOLUME = 0.001F;
    boundaryFieldSound = new BoundaryFieldSound(resourceLocation, INITIAL_VOLUME, true);
    soundController.playSound(boundaryFieldSound);
    boundaryFieldSound.func_73660_a();
  }

  public void stopPlaying()
  {
    if (boundaryFieldSound != null) {
      soundController.stopSound(boundaryFieldSound);
      boundaryFieldSound = null;
    }
  }

  private SoundEffectNames soundEffectName;
  private SoundController soundController;
  private ResourceLocation resourceLocation;
  private BoundaryFieldSound boundaryFieldSound;
  private BoundaryHumUpdateLink boundaryHumUpdateLink;

  /**
   * Used as a callback to update the sound's position and
   */
  public interface BoundaryHumUpdateLink
  {
    public boolean refreshHumInfo(BoundaryHumInfo infoToUpdate);
  }

  public static class BoundaryHumInfo
  {
    public Vec3 soundEpicentre;
    public float distanceToEpicentre;
  }

  private class BoundaryFieldSound extends PositionedSound implements ITickableSound
  {
    public BoundaryFieldSound(ResourceLocation i_resourceLocation, float i_volume, boolean i_repeat)
    {
      super(i_resourceLocation);
      field_147659_g = i_repeat;
      field_147662_b = i_volume;
      field_147666_i = AttenuationType.NONE;
    }

    private boolean donePlaying;
    @Override
    public boolean func_147667_k() {
      return donePlaying;
    }

    /**
     * Updates the JList with a new model.
     */
    @Override
    public void func_73660_a() {
      BoundaryHumInfo boundaryHumInfo = new BoundaryHumInfo();
      boolean playing = boundaryHumUpdateLink.refreshHumInfo(boundaryHumInfo);
      final float MINIMUM_VOLUME = 0.01F;
      final float MAXIMUM_VOLUME = 0.05F;
      final float INSIDE_VOLUME = 0.10F;
      final float OFF_VOLUME = 0.0F;
      if (!playing) {
//        donePlaying = true;
        this.field_147662_b = OFF_VOLUME;
      } else {
//        System.out.println(boundaryHumInfo.distanceToEpicentre);
        this.field_147660_d = (float)boundaryHumInfo.soundEpicentre.field_72450_a;
        this.field_147661_e = (float)boundaryHumInfo.soundEpicentre.field_72448_b;
        this.field_147658_f = (float)boundaryHumInfo.soundEpicentre.field_72449_c;
        if (boundaryHumInfo.distanceToEpicentre < 0.01F) {
          this.field_147662_b = INSIDE_VOLUME;
        } else {
          final float MINIMUM_VOLUME_DISTANCE = 20.0F;
          float fractionToMinimum = boundaryHumInfo.distanceToEpicentre / MINIMUM_VOLUME_DISTANCE;
          this.field_147662_b = UsefulFunctions.clipToRange(MINIMUM_VOLUME,
                                                    MAXIMUM_VOLUME - fractionToMinimum * (MAXIMUM_VOLUME - MINIMUM_VOLUME),
                                                    MAXIMUM_VOLUME);
        }
      }
    }
  }

}
