package speedytools.clientside.userinput;

import net.minecraft.client.Minecraft;


/**
* registry for the various user input interceptors
*/
public class SpeedyToolControls
{
  public static KeyBindingInterceptor attackButtonInterceptor;
  public static KeyBindingInterceptor useItemButtonInterceptor;

  public static void initialiseInterceptors()
  {
    attackButtonInterceptor = new KeyBindingInterceptor(Minecraft.func_71410_x().field_71474_y.field_74312_F);
    Minecraft.func_71410_x().field_71474_y.field_74312_F = attackButtonInterceptor;
    attackButtonInterceptor.setInterceptionActive(false);

    useItemButtonInterceptor = new KeyBindingInterceptor(Minecraft.func_71410_x().field_71474_y.field_74313_G);
    Minecraft.func_71410_x().field_71474_y.field_74313_G = useItemButtonInterceptor;
    useItemButtonInterceptor.setInterceptionActive(false);
  }

  public static void enableClickInterception(boolean interception)
  {
    useItemButtonInterceptor.setInterceptionActive(interception);
    attackButtonInterceptor.setInterceptionActive(interception);
  }


}
